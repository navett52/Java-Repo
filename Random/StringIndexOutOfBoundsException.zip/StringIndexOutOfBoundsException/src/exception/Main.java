package exception;

public class Main {

	public static void main(String[] args) {
		String coordinateFileName = "coord_-1,10";
		//This works fine
		String coordinate = coordinateFileName.substring(6, 8);
		System.out.println(coordinate);
		//This does not work, but I thought I was able to supply a character and it would
		//return the index of that character within the string, but now I'm feeling like
		//instead of returning the index, it just uses a numerical value of the char?
		String coord = coordinateFileName.substring('_', ',');
		System.out.println(coord);
	}

}

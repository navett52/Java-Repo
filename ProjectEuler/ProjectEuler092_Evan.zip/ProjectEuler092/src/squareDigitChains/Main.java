package squareDigitChains;

public class Main {

	public static void main(String[] args) {
		//System.out.println(11 % 10);
		SquareDigitChains chain = new SquareDigitChains();
		int answer = chain.squareDigitChains();
		System.out.println(answer);
		
		//Temp x = new Temp();
		//int answer = x.squareDigitChains();
		//System.out.println(answer);
	}

}

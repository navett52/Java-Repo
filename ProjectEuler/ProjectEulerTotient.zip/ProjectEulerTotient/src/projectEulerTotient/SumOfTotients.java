package projectEulerTotient;

import java.util.ArrayList;

public class SumOfTotients {
	
	public int sumOfTotients() {
		int sum = 0;
		int primeCount = 0;
		int count = 0;
		for (int i = 2; i < Integer.MAX_VALUE; i++) {
			if (i % 1000 == 0) {
				count++;
				System.out.println(count + " thousand increments have been traversed");
			}
			if (checkForPrime(i) == true) {
				primeCount++;
				sum += getTotient(i);
			}
			if (primeCount == 10000) {
				break;
			}
		}
		return sum;
	}
	/**
	 * Finds the totient value of a number
	 * @param number The number you want the totient value for
	 * @return The totient value of the specified number
	 */
	public int getTotient(int number) {
		//Initializing the totient count to 1 since 1 is relatively prime to all numbers
		int totient = 1;
		//Setting the commonFactorCount to 1 to ensure that it will inherently not effect the totient count
		int commonFactorCount = 1;
		//Cycle through and grab a number less than the specified number
		for (int i = 2; i < number; i++) {
			//Set commonFactorCount to 0 so that if there are no common factors totient will be incremented
			commonFactorCount = 0;
			//Cycle through the specified number to find it's factors
			for (int j = 2; j < number; j++) {
				//If j is a factor of the specified number
				if (number % j == 0) {
					//and if i shares that factor
					if (i % j == 0) {
						//commonFactorCount will increment
						commonFactorCount++;
						//and then break out of the loop
						break;
					}
				}
			}
			//if i makes it through to here without incrementing the commonFactorCount then totient will increment
			if (commonFactorCount == 0) {
				totient++;
			}
		}
		//return the total totient count of the specified number
		return totient;
	}
	
	public ArrayList getFactors(int number) {
		ArrayList<Integer> factors = new ArrayList<Integer>();
		factors.add(0);
		for (int i = 2; i < number; i++) {
			if (number % i == 0) {
				factors.add(i);
			}
		}
		return factors;
	}
	
	/**
	 * Checks for primeness.
	 * @param number The number to be checked.
	 * @return True or false whether the number is prime or not.
	 */
	public static boolean checkForPrime(int number) {
		//Cycle through all numbers, starting from 2 (since all numbers are divisible by 1), smaller than the number to be checked
	    for(int i = 2; i < number; i++) {
	    	//If a number is found that returns 0 as remainder the number is not prime and returns false
	        if(number % i == 0)
	            return false;
	    }
	    //If no number is found that returns a 0 remainder the number is prime.
	    return true;
	}
}
